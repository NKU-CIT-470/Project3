#Group Project 3 #Monit Configuration #CIT 470-001 #Instructor: Darci Guriel #Group: 1 #Members: #Dan Jones, Rick Replogle, Ryan Williams #06/21/2021

Name of File Description

monitrc_client Monit Client Configuration File

monitrc_server Monit Server Configuration File

monit-client-install Monit Script that pulls monitrc-client configurations file down from github

client_testing.sh Test script to test Monit monitoring on the clients

server_testing.sh Test script to test Monit monitoring on the server